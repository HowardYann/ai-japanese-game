// 独立跑一遍 buildChatContext 的纯逻辑测试，不需要数据库/网络/Claude API
// 直接用 npx tsx 执行 TypeScript，验证 system prompt 组装是否符合预期

import { mizuki } from "./lib/npc/data/mizuki.ts";
import { buildChatContext } from "./lib/context/buildContext.ts";

const fakeRelationship = {
  user_id: "test-user",
  npc_id: "mizuki",
  stage: "熟悉中",
  known_facts: { 上次话题: "咖啡店巡礼", 爱好: "爬山" },
  summary: "上次约好一起去咖啡店巡礼，还没成行。",
  updated_at: new Date().toISOString(),
};

const fakeTurns = [
  { id: "t1", event_id: "e1", role: "npc", content: "こんにちは！今日はどこ行くの？", created_at: "" },
  { id: "t2", event_id: "e1", role: "user", content: "今日は渋谷へ行くつもりです", created_at: "" },
];

const result = buildChatContext(mizuki, fakeRelationship, fakeTurns, "でも道がわからないんです");

console.log("=== SYSTEM PROMPT ===\n");
console.log(result.systemPrompt);
console.log("\n=== MESSAGES ===\n");
console.log(JSON.stringify(result.messages, null, 2));

// 基本断言：hidden字段绝不能出现在prompt里
if (result.systemPrompt.includes("unlockConditions")) {
  console.error("\n❌ FAIL: hidden字段泄漏进了system prompt！");
  process.exit(1);
} else {
  console.log("\n✅ PASS: hidden字段没有出现在system prompt里（白名单生效）");
}
if (result.messages[result.messages.length - 1].content !== "でも道がわからないんです") {
  console.error("❌ FAIL: 最新用户消息没有正确追加到messages末尾");
  process.exit(1);
} else {
  console.log("✅ PASS: 最新用户消息正确追加在messages末尾");
}
