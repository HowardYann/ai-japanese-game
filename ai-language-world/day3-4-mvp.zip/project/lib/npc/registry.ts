// lib/npc/registry.ts
import type { NpcConfig } from "./types";
import { mizuki } from "./data/mizuki";
import { taisho } from "./data/taisho";

const NPC_REGISTRY: Record<string, NpcConfig> = {
  mizuki,
  taisho,
};

export function getNpcConfig(npcId: string): NpcConfig {
  const npc = NPC_REGISTRY[npcId];
  if (!npc) {
    throw new Error(`Unknown npcId: ${npcId}`);
  }
  return npc;
}

export function listNpcIds(): string[] {
  return Object.keys(NPC_REGISTRY);
}
