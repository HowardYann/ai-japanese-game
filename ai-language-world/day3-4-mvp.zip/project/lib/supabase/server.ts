// lib/supabase/server.ts
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * 每次请求创建一个绑定当前用户会话的 Supabase client。
 * 所有 db/ 下的查询函数都应该拿这个 client 用，
 * 这样 Supabase 的 RLS（如果开了）和我们代码里的手动 user_id 过滤是双保险。
 */
export function getSupabaseServerClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
      },
    }
  );
}

/** 从当前会话取出登录用户id；未登录抛错，调用方负责转成401 */
export async function requireUserId(): Promise<string> {
  const supabase = getSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    throw new Error("UNAUTHENTICATED");
  }
  return user.id;
}
