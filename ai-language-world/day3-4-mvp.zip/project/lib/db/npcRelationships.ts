// lib/db/npcRelationships.ts
//
// 安全纪律 #1（对照交接文档第五节）：
// 所有查询手动带 user_id 过滤，不管多小的接口都不例外。
// 这个文件里每一条查询都显式 .eq("user_id", userId)，
// 即使 Supabase RLS 已经在做同样的事，这里也不省略——双保险，读代码时一眼能看出边界。

import { getSupabaseServerClient } from "../supabase/server";
import type { NpcRelationshipRow } from "./types";

/** 取某用户与某NPC的关系记录；不存在则返回 null（由调用方决定是否要初始化） */
export async function getRelationship(
  userId: string,
  npcId: string
): Promise<NpcRelationshipRow | null> {
  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("npc_relationships")
    .select("user_id, npc_id, stage, known_facts, summary, updated_at")
    .eq("user_id", userId)
    .eq("npc_id", npcId)
    .maybeSingle();

  if (error) throw error;
  return data as NpcRelationshipRow | null;
}

/** 首次见面时初始化一条初识关系 */
export async function createInitialRelationship(
  userId: string,
  npcId: string
): Promise<NpcRelationshipRow> {
  const supabase = getSupabaseServerClient();
  const initial: Omit<NpcRelationshipRow, "updated_at"> = {
    user_id: userId,
    npc_id: npcId,
    stage: "初识",
    known_facts: {},
    summary: "",
  };

  const { data, error } = await supabase
    .from("npc_relationships")
    .insert(initial)
    .select()
    .single();

  if (error) throw error;
  return data as NpcRelationshipRow;
}

/** 取不到就建一条，保证调用方总能拿到一条关系记录 */
export async function getOrCreateRelationship(
  userId: string,
  npcId: string
): Promise<NpcRelationshipRow> {
  const existing = await getRelationship(userId, npcId);
  if (existing) return existing;
  return createInitialRelationship(userId, npcId);
}

/**
 * 对话结束后整体覆盖式更新（不是追加）。
 * 对照交接文档第二节明确排除项：relationship_notes 不做AI自由追加的黑箱文本，
 * summary 每次由AI重新生成整段摘要，known_facts 是结构化字段的整体替换。
 */
export async function updateRelationshipSummary(
  userId: string,
  npcId: string,
  update: {
    stage?: string;
    knownFacts?: Record<string, unknown>;
    summary: string;
  }
): Promise<NpcRelationshipRow> {
  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("npc_relationships")
    .update({
      ...(update.stage ? { stage: update.stage } : {}),
      ...(update.knownFacts ? { known_facts: update.knownFacts } : {}),
      summary: update.summary,
      updated_at: new Date().toISOString(),
    })
    .eq("user_id", userId) // 纪律 #1：即使按主键更新，也带上 user_id
    .eq("npc_id", npcId)
    .select()
    .single();

  if (error) throw error;
  return data as NpcRelationshipRow;
}
