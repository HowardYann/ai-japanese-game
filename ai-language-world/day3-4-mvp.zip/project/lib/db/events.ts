// lib/db/events.ts
import { getSupabaseServerClient } from "../supabase/server";
import type { EventRow, ConversationTurnRow } from "./types";

/** 开始一场新的对话事件（玩家点击"去找瑞希聊天"时调用一次） */
export async function createEvent(
  userId: string,
  npcId: string
): Promise<EventRow> {
  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("events")
    .insert({ user_id: userId, npc_id: npcId })
    .select()
    .single();

  if (error) throw error;
  return data as EventRow;
}

/**
 * 校验某个 event 确实属于当前用户，返回该 event。
 * 任何往 event 里追加 turn 的操作之前都要先过这一关——
 * 防止用户A传一个别人的 eventId 进来写内容。
 */
export async function getOwnedEvent(
  eventId: string,
  userId: string
): Promise<EventRow> {
  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("events")
    .select("*")
    .eq("id", eventId)
    .eq("user_id", userId) // 纪律 #1
    .maybeSingle();

  if (error) throw error;
  if (!data) throw new Error("EVENT_NOT_FOUND_OR_NOT_OWNED");
  return data as EventRow;
}

/** 取某场事件目前为止的对话轮次，按时间正序，用于组装上下文 */
export async function getTurnsForEvent(
  eventId: string,
  userId: string
): Promise<ConversationTurnRow[]> {
  // 先确认归属权，再查turn
  await getOwnedEvent(eventId, userId);

  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("conversation_turns")
    .select("*")
    .eq("event_id", eventId)
    .order("created_at", { ascending: true });

  if (error) throw error;
  return (data ?? []) as ConversationTurnRow[];
}

/** 追加一条对话轮次（用户发言或NPC回应） */
export async function appendTurn(
  eventId: string,
  userId: string,
  role: "user" | "npc",
  content: string
): Promise<ConversationTurnRow> {
  await getOwnedEvent(eventId, userId); // 归属权校验

  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("conversation_turns")
    .insert({ event_id: eventId, role, content })
    .select()
    .single();

  if (error) throw error;
  return data as ConversationTurnRow;
}

/** 场次结束时归档：写入事件摘要 + 可能的人生收藏标题 */
export async function closeEvent(
  eventId: string,
  userId: string,
  summary: {
    text: string;
    lifeCollectionTitle?: string | null;
  }
): Promise<EventRow> {
  await getOwnedEvent(eventId, userId);

  const supabase = getSupabaseServerClient();
  const { data, error } = await supabase
    .from("events")
    .update({
      summary: summary.text,
      life_collection_title: summary.lifeCollectionTitle ?? null,
    })
    .eq("id", eventId)
    .eq("user_id", userId) // 纪律 #1
    .select()
    .single();

  if (error) throw error;
  return data as EventRow;
}
